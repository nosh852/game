gdjs.LoginCode = {};
gdjs.LoginCode.localVariables = [];
gdjs.LoginCode.GDUsernameObjects1= [];
gdjs.LoginCode.GDUsernameObjects2= [];
gdjs.LoginCode.GDEmailObjects1= [];
gdjs.LoginCode.GDEmailObjects2= [];
gdjs.LoginCode.GDUsernameTitleObjects1= [];
gdjs.LoginCode.GDUsernameTitleObjects2= [];
gdjs.LoginCode.GDEmailTitleObjects1= [];
gdjs.LoginCode.GDEmailTitleObjects2= [];
gdjs.LoginCode.GDNewPanelSpriteObjects1= [];
gdjs.LoginCode.GDNewPanelSpriteObjects2= [];
gdjs.LoginCode.GDNewSpriteObjects1= [];
gdjs.LoginCode.GDNewSpriteObjects2= [];
gdjs.LoginCode.GDRegisterButtonObjects1= [];
gdjs.LoginCode.GDRegisterButtonObjects2= [];
gdjs.LoginCode.GDRegisterButton2Objects1= [];
gdjs.LoginCode.GDRegisterButton2Objects2= [];
gdjs.LoginCode.GDorChoiceObjects1= [];
gdjs.LoginCode.GDorChoiceObjects2= [];
gdjs.LoginCode.GDsign_9595up_9595textObjects1= [];
gdjs.LoginCode.GDsign_9595up_9595textObjects2= [];
gdjs.LoginCode.GDHighScoreFinalObjects1= [];
gdjs.LoginCode.GDHighScoreFinalObjects2= [];
gdjs.LoginCode.GDPasswordInputObjects1= [];
gdjs.LoginCode.GDPasswordInputObjects2= [];
gdjs.LoginCode.GDPasswordTitleObjects1= [];
gdjs.LoginCode.GDPasswordTitleObjects2= [];
gdjs.LoginCode.GDButton_9595AObjects1= [];
gdjs.LoginCode.GDButton_9595AObjects2= [];
gdjs.LoginCode.GDB_9595buttonObjects1= [];
gdjs.LoginCode.GDB_9595buttonObjects2= [];
gdjs.LoginCode.GDCoinScoreObjects1= [];
gdjs.LoginCode.GDCoinScoreObjects2= [];
gdjs.LoginCode.GDScoreRunObjects1= [];
gdjs.LoginCode.GDScoreRunObjects2= [];
gdjs.LoginCode.GDgameboy_9595joystickObjects1= [];
gdjs.LoginCode.GDgameboy_9595joystickObjects2= [];
gdjs.LoginCode.GDSave_9595ButtonObjects1= [];
gdjs.LoginCode.GDSave_9595ButtonObjects2= [];
gdjs.LoginCode.GDRestart_9595ButtonObjects1= [];
gdjs.LoginCode.GDRestart_9595ButtonObjects2= [];
gdjs.LoginCode.GDGameOverObjects1= [];
gdjs.LoginCode.GDGameOverObjects2= [];
gdjs.LoginCode.GDScrollGroundStillObjects1= [];
gdjs.LoginCode.GDScrollGroundStillObjects2= [];
gdjs.LoginCode.GDFinalCoinScoreObjects1= [];
gdjs.LoginCode.GDFinalCoinScoreObjects2= [];


gdjs.LoginCode.eventsList0 = function(runtimeScene) {

};gdjs.LoginCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


gdjs.LoginCode.eventsList0(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("FinalCoinScore"), gdjs.LoginCode.GDFinalCoinScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("HighScoreFinal"), gdjs.LoginCode.GDHighScoreFinalObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDFinalCoinScoreObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDFinalCoinScoreObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}{for(var i = 0, len = gdjs.LoginCode.GDHighScoreFinalObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDHighScoreFinalObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FinalCoinScore"), gdjs.LoginCode.GDFinalCoinScoreObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber((gdjs.RuntimeObject.getLastVariableNumber(((gdjs.LoginCode.GDFinalCoinScoreObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDFinalCoinScoreObjects1[0].getVariables()).get("GlobalCoinScore"))));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RegisterButton2"), gdjs.LoginCode.GDRegisterButton2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDRegisterButton2Objects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDRegisterButton2Objects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDRegisterButton2Objects1[k] = gdjs.LoginCode.GDRegisterButton2Objects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDRegisterButton2Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.firebaseTools.firestore.addDocument("Scoreboard", gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable);
}}

}


};

gdjs.LoginCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LoginCode.GDUsernameObjects1.length = 0;
gdjs.LoginCode.GDUsernameObjects2.length = 0;
gdjs.LoginCode.GDEmailObjects1.length = 0;
gdjs.LoginCode.GDEmailObjects2.length = 0;
gdjs.LoginCode.GDUsernameTitleObjects1.length = 0;
gdjs.LoginCode.GDUsernameTitleObjects2.length = 0;
gdjs.LoginCode.GDEmailTitleObjects1.length = 0;
gdjs.LoginCode.GDEmailTitleObjects2.length = 0;
gdjs.LoginCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.LoginCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.LoginCode.GDNewSpriteObjects1.length = 0;
gdjs.LoginCode.GDNewSpriteObjects2.length = 0;
gdjs.LoginCode.GDRegisterButtonObjects1.length = 0;
gdjs.LoginCode.GDRegisterButtonObjects2.length = 0;
gdjs.LoginCode.GDRegisterButton2Objects1.length = 0;
gdjs.LoginCode.GDRegisterButton2Objects2.length = 0;
gdjs.LoginCode.GDorChoiceObjects1.length = 0;
gdjs.LoginCode.GDorChoiceObjects2.length = 0;
gdjs.LoginCode.GDsign_9595up_9595textObjects1.length = 0;
gdjs.LoginCode.GDsign_9595up_9595textObjects2.length = 0;
gdjs.LoginCode.GDHighScoreFinalObjects1.length = 0;
gdjs.LoginCode.GDHighScoreFinalObjects2.length = 0;
gdjs.LoginCode.GDPasswordInputObjects1.length = 0;
gdjs.LoginCode.GDPasswordInputObjects2.length = 0;
gdjs.LoginCode.GDPasswordTitleObjects1.length = 0;
gdjs.LoginCode.GDPasswordTitleObjects2.length = 0;
gdjs.LoginCode.GDButton_9595AObjects1.length = 0;
gdjs.LoginCode.GDButton_9595AObjects2.length = 0;
gdjs.LoginCode.GDB_9595buttonObjects1.length = 0;
gdjs.LoginCode.GDB_9595buttonObjects2.length = 0;
gdjs.LoginCode.GDCoinScoreObjects1.length = 0;
gdjs.LoginCode.GDCoinScoreObjects2.length = 0;
gdjs.LoginCode.GDScoreRunObjects1.length = 0;
gdjs.LoginCode.GDScoreRunObjects2.length = 0;
gdjs.LoginCode.GDgameboy_9595joystickObjects1.length = 0;
gdjs.LoginCode.GDgameboy_9595joystickObjects2.length = 0;
gdjs.LoginCode.GDSave_9595ButtonObjects1.length = 0;
gdjs.LoginCode.GDSave_9595ButtonObjects2.length = 0;
gdjs.LoginCode.GDRestart_9595ButtonObjects1.length = 0;
gdjs.LoginCode.GDRestart_9595ButtonObjects2.length = 0;
gdjs.LoginCode.GDGameOverObjects1.length = 0;
gdjs.LoginCode.GDGameOverObjects2.length = 0;
gdjs.LoginCode.GDScrollGroundStillObjects1.length = 0;
gdjs.LoginCode.GDScrollGroundStillObjects2.length = 0;
gdjs.LoginCode.GDFinalCoinScoreObjects1.length = 0;
gdjs.LoginCode.GDFinalCoinScoreObjects2.length = 0;

gdjs.LoginCode.eventsList1(runtimeScene);
gdjs.LoginCode.GDUsernameObjects1.length = 0;
gdjs.LoginCode.GDUsernameObjects2.length = 0;
gdjs.LoginCode.GDEmailObjects1.length = 0;
gdjs.LoginCode.GDEmailObjects2.length = 0;
gdjs.LoginCode.GDUsernameTitleObjects1.length = 0;
gdjs.LoginCode.GDUsernameTitleObjects2.length = 0;
gdjs.LoginCode.GDEmailTitleObjects1.length = 0;
gdjs.LoginCode.GDEmailTitleObjects2.length = 0;
gdjs.LoginCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.LoginCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.LoginCode.GDNewSpriteObjects1.length = 0;
gdjs.LoginCode.GDNewSpriteObjects2.length = 0;
gdjs.LoginCode.GDRegisterButtonObjects1.length = 0;
gdjs.LoginCode.GDRegisterButtonObjects2.length = 0;
gdjs.LoginCode.GDRegisterButton2Objects1.length = 0;
gdjs.LoginCode.GDRegisterButton2Objects2.length = 0;
gdjs.LoginCode.GDorChoiceObjects1.length = 0;
gdjs.LoginCode.GDorChoiceObjects2.length = 0;
gdjs.LoginCode.GDsign_9595up_9595textObjects1.length = 0;
gdjs.LoginCode.GDsign_9595up_9595textObjects2.length = 0;
gdjs.LoginCode.GDHighScoreFinalObjects1.length = 0;
gdjs.LoginCode.GDHighScoreFinalObjects2.length = 0;
gdjs.LoginCode.GDPasswordInputObjects1.length = 0;
gdjs.LoginCode.GDPasswordInputObjects2.length = 0;
gdjs.LoginCode.GDPasswordTitleObjects1.length = 0;
gdjs.LoginCode.GDPasswordTitleObjects2.length = 0;
gdjs.LoginCode.GDButton_9595AObjects1.length = 0;
gdjs.LoginCode.GDButton_9595AObjects2.length = 0;
gdjs.LoginCode.GDB_9595buttonObjects1.length = 0;
gdjs.LoginCode.GDB_9595buttonObjects2.length = 0;
gdjs.LoginCode.GDCoinScoreObjects1.length = 0;
gdjs.LoginCode.GDCoinScoreObjects2.length = 0;
gdjs.LoginCode.GDScoreRunObjects1.length = 0;
gdjs.LoginCode.GDScoreRunObjects2.length = 0;
gdjs.LoginCode.GDgameboy_9595joystickObjects1.length = 0;
gdjs.LoginCode.GDgameboy_9595joystickObjects2.length = 0;
gdjs.LoginCode.GDSave_9595ButtonObjects1.length = 0;
gdjs.LoginCode.GDSave_9595ButtonObjects2.length = 0;
gdjs.LoginCode.GDRestart_9595ButtonObjects1.length = 0;
gdjs.LoginCode.GDRestart_9595ButtonObjects2.length = 0;
gdjs.LoginCode.GDGameOverObjects1.length = 0;
gdjs.LoginCode.GDGameOverObjects2.length = 0;
gdjs.LoginCode.GDScrollGroundStillObjects1.length = 0;
gdjs.LoginCode.GDScrollGroundStillObjects2.length = 0;
gdjs.LoginCode.GDFinalCoinScoreObjects1.length = 0;
gdjs.LoginCode.GDFinalCoinScoreObjects2.length = 0;


return;

}

gdjs['LoginCode'] = gdjs.LoginCode;
